/**************************************************
 * Name: Dallin Drollinger
 * A#: A01984170
 * Description: Contains all handlers for input
 *************************************************/
'use strict';

let MazeHandlers = function(spec) {
    return {
    };
};
